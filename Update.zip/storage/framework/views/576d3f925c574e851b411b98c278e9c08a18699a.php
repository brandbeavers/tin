<div style="max-width: 600px; ">
    <?php echo e(__('lang.hello', [], $lang)); ?> <i><?php echo e($data->receiver); ?></i>,
    <h1><?php echo e(__('lang.almost_there', [], $lang)); ?></h1>
    <h4><?php echo e(__('lang.created_account', [], $lang)); ?></h4>
    <p><?php echo e(__('lang.verify_email', [], $lang)); ?></p>
    <p><?php echo e(__('lang.code_below', [], $lang)); ?></p>

    <p>
        <span style="background: #39AEA4; padding: 10px 30px; margin: 20px 0; display: inline-block;
                        border-radius: 100px; font-size: 20px; color: #fff; letter-spacing: 1px;">
            <b><?php echo e($data->code); ?></b>
        </span>
    </p>
    <?php echo e(__('lang.thank_you', [], $lang)); ?>


    <h3><?php echo e($data->store_name); ?></h3>

    <div style="margin-top: 20px; border-top: 1px solid #eee;">
        <p><?php echo e($data->address); ?></p>
        <p><?php echo e(__('lang.phone', [], $lang)); ?>: <a href="tel:<?php echo e($data->phone); ?>"><?php echo e($data->phone); ?></a></p>
    </div>

</div>
<?php /**PATH G:\Full Project\Server\backend\resources\views/mail_templates/user_registration.blade.php ENDPATH**/ ?>