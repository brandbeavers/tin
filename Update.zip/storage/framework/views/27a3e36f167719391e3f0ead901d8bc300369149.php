
<?php /*include app_path() . './../index.html'; */?>


<?php include app_path() . './../public/index.html'; ?>

<?php /**PATH G:\Full Project\Server\backend\resources\views/welcome.blade.php ENDPATH**/ ?>