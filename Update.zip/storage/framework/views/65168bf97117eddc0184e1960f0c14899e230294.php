<?php include app_path() . './../index.html'; ?>
<?php /**PATH C:\xampp\htdocs\resources\views/welcome.blade.php ENDPATH**/ ?>