

<?php /*include app_path() . './../admin/index.html'; */?>


<?php include app_path() . './../public/admin/index.html'; ?>
<?php /**PATH G:\Full Project\Server\backend\resources\views/admin.blade.php ENDPATH**/ ?>