{{--For cpanel--}}
<?php include app_path() . './../admin/index.html'; ?>

{{--For artisan / VPS--}}
<?php /*include app_path() . './../public/admin/index.html'; */?>
