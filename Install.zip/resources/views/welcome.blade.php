{{--For cpanel--}}
<?php include app_path() . './../index.html'; ?>

{{--For artisan / VPS--}}
<?php /*include app_path() . './../public/index.html'; */?>

